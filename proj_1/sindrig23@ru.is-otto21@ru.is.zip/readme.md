#
Python version 3.12.7

Virtual environment setup með venv

#
install dependencies

	pip install -r requirements.txt

#
Svör við skriflegum spurningum má finna í skriflegar_spurningar.txt